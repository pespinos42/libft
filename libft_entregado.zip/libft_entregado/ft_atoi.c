/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/22 18:36:05 by pespinos          #+#    #+#             */
/*   Updated: 2022/09/26 16:09:46 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>
#include "libft.h"

typedef struct atoi_data
{
	int	result;
	int	sign;
	int	s;
	int	p;
}	t_atoi_data;

int	ft_atoi(const char *str)
{
	t_atoi_data	ad;

	ad.result = 0;
	ad.sign = 1;
	ad.s = 0;
	while ((*str >= 9 && *str <= 13) || *str == ' ')
		str++;
	if (*str == '+')
	{
		str++;
		ad.s = 1;
	}
	if (*str == '-' && ad.s == 0)
	{
		ad.sign = -1;
		str++;
	}
	else if (*str == '-' && ad.s == 1)
		ad.sign = 0;
	while (*str >= '0' && *str <= '9')
	{
		ad.result = ad.result * 10 + (*str - 48);
		str++;
	}
	return (ad.result * ad.sign);
}

// int	main()
// {
// 	char *str;

// 	str = " -129834ab567";
// 	int a = ft_atoi(str);

// 	printf("NUMERO %i\n", a);
// }
