/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isdigit.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/23 10:59:14 by pespinos          #+#    #+#             */
/*   Updated: 2022/09/25 13:05:16 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <stdio.h>
//#include <ctype.h>
#include "libft.h"

int	ft_isdigit(int c)
{
	return (c >= 48 && c <= 57);
}

/*int main()
{
	int	l;

	l = 20;
	printf("MIA %i es %i\n", l, ft_isdigit(l));
	printf("OFICIAL %i es %i\n", l, isdigit(l));
	l = 48;
	printf("MIA %i es %i\n", l, ft_isdigit(l));
	printf("OFICIAL %i es %i\n", l, isdigit(l));
	return(0);
}*/
