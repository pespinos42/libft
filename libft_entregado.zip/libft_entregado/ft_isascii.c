/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isascii.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/23 10:58:44 by pespinos          #+#    #+#             */
/*   Updated: 2022/09/25 13:07:50 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <ctype.h>
//#include <stdio.h>
#include "libft.h"

int	ft_isascii(int c)
{
	return (c >= 0 && c <= 127);
}

/*int main()
{
	int	l;

	l = 300;
	printf("MIA %i es %i\n", l, ft_isascii(l));
	printf("OFICIAL %i es %i\n", l, isascii(l));
	l = 30;
	printf("MIA %i es %i\n", l, ft_isascii(l));
	printf("OFICIAL %i es %i\n", l, isascii(l));
	return(0);
}*/
