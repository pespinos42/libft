/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/25 15:14:35 by pespinos          #+#    #+#             */
/*   Updated: 2022/10/02 13:18:10 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	char		*str;
	size_t		p;

	p = 0;
	if (ft_strlen(s) < start)
		return (ft_strdup(""));
	if (ft_strlen(&s[start]) < len)
		len = ft_strlen(&s[start]);
	str = (char *) malloc((len + 1) * sizeof(char));
	if (str)
	{
		while (p < len && s[p + start])
		{
			str[p] = s[p + start];
			p++;
		}
		str[p] = '\0';
		return (str);
	}
	else
	{
		free(str);
		return (NULL);
	}
}

/*int main()
{
    char *str = "loren ipsum dolores";
    printf("%s\n", ft_substr(str, 0, 10));
	free(str);
    return 0;
}*/