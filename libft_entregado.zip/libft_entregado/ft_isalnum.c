/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_isalnum.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/23 10:57:09 by pespinos          #+#    #+#             */
/*   Updated: 2022/09/25 13:06:39 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

//#include <ctype.h>
//#include <stdio.h>
#include "libft.h"

int	ft_isalnum(int c)
{
	return (ft_isalpha(c) || ft_isdigit(c));
}

/*int main()
{
	int	l;

	l = 40;
	printf("MIA %i es %i\n", l, ft_isalnum(l));
	printf("OFICIAL %i es %i\n", l, isalnum(l));
	l = 57;
	printf("MIA %i es %i\n", l, ft_isalnum(l));
	printf("OFICIAL %i es %i\n", l, isalnum(l));
	return(0);
}*/
