/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memchr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/23 10:55:16 by pespinos          #+#    #+#             */
/*   Updated: 2022/10/02 12:20:57 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memchr(const void *ptr, int ch, size_t count)
{
	unsigned char	*str;
	unsigned char	l;

	str = (unsigned char *)ptr;
	l = (unsigned char) ch;
	while (count > 0)
	{
		if (*str == l)
			return (str);
		str++;
		count --;
	}
	return (NULL);
}
