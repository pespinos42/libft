/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/21 11:37:24 by pespinos          #+#    #+#             */
/*   Updated: 2022/10/02 12:31:00 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memset(void *b, int c, size_t len)
{
	unsigned char	*str;
	unsigned char	letter;

	letter = (unsigned char) c;
	str = (unsigned char *) b;
	while (len > 0)
	{
		*str = letter;
		str++;
		len--;
	}
	return (b);
}

/*int main()
{
	char *str;
	char *str2;

	str = (char*)malloc(3*sizeof(char));
	str2 = (char*)malloc(3*sizeof(char));

	printf("MIA %s\n", ft_memset(str, 'a', 3));
	printf("OFICIAL %s\n", memset(str2, 'a', 3));
	return (0);
}*/
