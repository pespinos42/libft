/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/26 10:05:49 by pespinos          #+#    #+#             */
/*   Updated: 2022/10/02 13:43:37 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static void	*ft_clear(char *str)
{
	free (str);
	return (NULL);
}

char	*ft_strjoin(char const *s1, char const *s2)
{
	int		total_len;
	char	*str;
	int		p;

	p = 0;
	total_len = ft_strlen(s1) + ft_strlen(s2);
	str = (char *) malloc((total_len + 1) * sizeof(char));
	if (str)
	{
		while (*s1)
		{
			str[p++] = *s1;
			s1++;
		}
		while (*s2)
		{
			str[p++] = *s2;
			s2++;
		}
		str[p] = '\0';
		return (str);
	}
	else
		return (ft_clear(str));
}

// int main()
// {
// 	printf("%s\n", ft_strjoin("hola", "abc"));
// 	return 0;
// }