/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pespinos <pespinos@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/09/23 10:54:42 by pespinos          #+#    #+#             */
/*   Updated: 2022/10/02 12:31:49 by pespinos         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlen(const char *s)
{
	size_t	len;

	len = 0;
	while (s[len])
	{
		len++;
	}
	return (len);
}

/*int main()
{
	printf("MIA HOLA -> %zu\n", ft_strlen("HOLA"));
	printf("OFICIAL HOLA -> %zu\n", strlen("HOLA"));
	return (0);
}*/
